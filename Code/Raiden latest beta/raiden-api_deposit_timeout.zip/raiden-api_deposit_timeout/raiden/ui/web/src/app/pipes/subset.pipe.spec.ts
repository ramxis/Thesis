import { SubsetPipe } from './subset.pipe';

describe('SubsetPipe', () => {
  it('create an instance', () => {
    const pipe = new SubsetPipe();
    expect(pipe).toBeTruthy();
  });
});
