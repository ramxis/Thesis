export const environment = {
  production: true,
  configFile: 'assets/config/config.production.json'
};
