# -*- coding: utf-8 -*-
from datetime import timedelta

MEGA = float(2 ** 20)
SECOND = 1
MINUTE = 60 * SECOND
ONESECOND_TIMEDELTA = timedelta(days=0, seconds=1)
INTERVAL_SECONDS = 1.0
