#!/usr/bin/env sh
"./.travis/download_geth.sh"
"./.travis/download_solc.sh"
